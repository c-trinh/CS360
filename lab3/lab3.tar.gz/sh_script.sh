#! /bin/bash

echo This sh script is excuted by bash

for NAME in $(ls)
do
  echo -n "$NAME "
done
echo
echo done with sh script


